
/**
 *
 * @author Carlos Fernandez
 * @version 1.0
 */
public class ImpresoraInyeccion extends Impresora {

    private double mililitros;
    private double capacidadMax;

    public double porcentajeActual() {
        if(isEncendido()){
            return capacidadMax * mililitros / 100;
        }else{
            System.out.println("Error, impresora apagada");
            return 0;
        }
    }

    public double getCapacidadMax() {
        return capacidadMax;
    }

    public void setCapacidadMax(double capacidadMax) {
        this.capacidadMax = capacidadMax;
    }

    public void cambiarCartucho(double capacidad) {
        if (isEncendido() == false) {
            mililitros = capacidad;
        } else if (capacidad <= 0) {
            System.out.println("Error, Cartucho vacio");
        } else if (isEncendido() == true) {
            System.out.println("Error, tienes que apagar la impresora para cambiar el cartucho");
        }

    }

    public double getMililitros() {
        return mililitros;
    }

    public void setMililitros(double mililitros) {
        this.mililitros = mililitros;
    }

    @Override
    public void imprimir(String texto) {
        if (isEncendido()) {
            if (mililitros <= 0) {
                System.out.println("No hay tinta, cambie el cartucho");
            } else {
                System.out.println("Imprimiendo texto...");
                mililitros = mililitros - (0.1 * texto.length());
                if (mililitros <= 0) {
                    System.out.println("No se pudo imprimir el documento completo");
                    mililitros = 0;
                }
            }
        }else{
            System.out.println("Error, impresora apagada");
        }

    }

    @Override
    public void imprimirPaginaPrueba() {
        if (isEncendido()) {
            imprimir("Página de prueba de la impresora de inyección con un cartucho de " + capacidadMax + " mililitros de tinta que actualmente está al " + porcentajeActual() + "% de su capacidad.");
        } else {
            System.out.println("Error, impresora apagada");
        }

    }

}
