/**
 *
 * @author Carlos Fernandez
 * @version 1.0
 */
public class ImresoraLaser extends Impresora {
    
    public final void calentarToner(){
        System.out.println("El tóner se está calentando");
    }

    public final void magnetizarPapel(){
        System.out.println("El papel se está magnetizando");
    }
    
    @Override
    public void imprimir(String texto) {
        if(isEncendido()){
            calentarToner();
            magnetizarPapel();
            System.out.println("Imprimiendo: "+texto);
        }else{
            System.out.println("Error, Impresora Apagada");
        }
        
    }

    @Override
    public void imprimirPaginaPrueba() {
        if(isEncendido()){
            imprimir("Página de prueba de la impresora láser…");
        }else{
            System.out.println("Error, Impresora Apagada");
        }
        
    }

    
    
}
