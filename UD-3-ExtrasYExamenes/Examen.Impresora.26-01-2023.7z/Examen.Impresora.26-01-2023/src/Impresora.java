/**
 *
 * @author Carlos Fernandez
 * @version 1.0
 */
public abstract class Impresora {

    private boolean encendido;
    
    public void encender(){
        encendido=true;
    }
    
    public void apagar(){
        encendido=false;
    }

    public boolean isEncendido() {
        return encendido;
    }
    
    public abstract void imprimir(String texto);
    
    public abstract void imprimirPaginaPrueba();
    
}
