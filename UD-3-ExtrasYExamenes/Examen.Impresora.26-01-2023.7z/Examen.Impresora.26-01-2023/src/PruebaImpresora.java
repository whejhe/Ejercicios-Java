/**
 *
 * @author usuario
 */
public class PruebaImpresora {
    public static void main(String[] args) {
        
        ImresoraLaser imp = new ImresoraLaser();
        ImpresoraInyeccion imp2 = new ImpresoraInyeccion();
        
        System.out.println("Impresora Laser");
        //imp.encender();
        imp.calentarToner();
        imp.magnetizarPapel();
        imp.imprimir("Algo por aqui");
        imp.imprimirPaginaPrueba();
        
        System.out.println("");
        
        System.out.println("Impresora de Inyeccion");
        imp2.encender();
        imp2.porcentajeActual();
        imp2.setCapacidadMax(100);
        imp2.setMililitros(100);
        imp2.imprimir("Algo por aqui");
        imp2.imprimirPaginaPrueba();
        imp2.cambiarCartucho(100);
        
    }
}
