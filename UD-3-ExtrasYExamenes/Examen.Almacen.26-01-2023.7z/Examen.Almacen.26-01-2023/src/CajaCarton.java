
/**
 *
 * @author Carlos Fernandez
 * @version 1.0
 */
public class CajaCarton implements Almacenable {

    private int codigo;
    private double altura;
    private double anchura;
    private double profundidad;
    private int numEstanteria;

    public CajaCarton(int codigo, double altura, double anchura, double profundidad) {
        this.codigo = codigo;
        this.altura = altura;
        this.anchura = anchura;
        this.profundidad = profundidad;
    }

    @Override
    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    @Override
    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    @Override
    public double getAnchura() {
        return anchura;
    }

    public void setAnchura(double anchura) {
        this.anchura = anchura;
    }

    @Override
    public double getProfundidad() {
        return profundidad;
    }

    public void setProfundidad(double profundidad) {
        this.profundidad = profundidad;
    }

    @Override
    public double calculaVolumen() {
        return getAnchura() * getAltura() * getProfundidad();
    }

    @Override
    public void almacena(int numEstanteria) {
        this.numEstanteria = numEstanteria;
        System.out.println("Se ha almacenado la caja con código " + getCodigo() + " en la estantería " + numEstanteria);
    }

    @Override
    public int localiza() {
        return numEstanteria;
    }

    @Override
    public void retira() {
        numEstanteria = 0;
    }

}
