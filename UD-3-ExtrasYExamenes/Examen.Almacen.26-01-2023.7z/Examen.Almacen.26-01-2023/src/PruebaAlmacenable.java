
/**
 *
 * @author Carlos Fernandez
 * @version 1.0
 */
import java.util.Scanner;

public class PruebaAlmacenable {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        CajaCarton c = new CajaCarton(1,0,0,0);
        int option;
        int codigo=1;
        do {
            System.out.println("MENU DE OPCIONES");
            System.out.println("0 - Salir");
            System.out.println("1 - Almacena");
            option = sc.nextInt();

            switch (option) {
                case 0:
                    break;
                case 1:
                    System.out.println("Dime anchura");
                    c.setAnchura(sc.nextDouble());
                    System.out.println("Dime profundidad");
                    c.setProfundidad(sc.nextDouble());
                    System.out.println("Dime Altura");
                    c.setAltura(sc.nextDouble());
                    new CajaCarton(codigo,c.getAltura(),c.getAnchura(),c.getProfundidad());
                    codigo++;
                    
                    System.out.println("Volumen: "+c.calculaVolumen());
                    if(c.calculaVolumen()<5000){
                        c.almacena(1);
                    }else{
                        c.almacena(2);
                    }
                    break;
                default:
                    System.out.println("Opcion Incorrecta");
                    break;
            }

        } while (option != 0);

    }
}
